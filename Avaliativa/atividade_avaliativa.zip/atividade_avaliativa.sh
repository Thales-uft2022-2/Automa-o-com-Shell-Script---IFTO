#!/bin/bash

# ============================================================
# ATIVIDADE AVALIATIVA - SHELL SCRIPT
# Disciplina: Automação / Shell Script
#
# Conteúdos utilizados:
# - Variáveis
# - Entrada de dados
# - Validação
# - if / elif / else
# - case
# - for
# - while
# - Manipulação de arquivos e diretórios
# - Parâmetros
# - PID
# - Menu principal
# ============================================================


# ============================================================
# FUNÇÃO PARA PAUSAR O PROGRAMA
# ============================================================

pausar() {
    echo ""
    read -p "Pressione ENTER para continuar..."
}


# ============================================================
# EXERCÍCIO 1
# VALIDAR SE UM NÚMERO É MAIOR QUE 10
#
# Conteúdo:
# - Entrada do usuário
# - Validação
# - if
# - PID
# ============================================================

exercicio1() {

    clear

    echo "========================================"
    echo " EXERCÍCIO 1 - NÚMERO MAIOR QUE 10"
    echo "========================================"
    echo ""

    read -p "Digite um número inteiro: " numero

    # Validação da entrada
    if ! [[ "$numero" =~ ^-?[0-9]+$ ]]; then

        echo ""
        echo "ERRO: Digite apenas números inteiros."

        pausar
        return
    fi


    # Verificação usando IF
    if [ "$numero" -gt 10 ]; then

        echo ""
        echo "O número $numero é MAIOR que 10."
        echo "Nome do script: $0"
        echo "PID do script: $$"

    elif [ "$numero" -eq 10 ]; then

        echo ""
        echo "O número informado é exatamente 10."

    else

        echo ""
        echo "O número $numero é MENOR que 10."

    fi

    pausar
}


# ============================================================
# EXERCÍCIO 2
# VERIFICAR ARQUIVO E REALIZAR BACKUP
#
# Conteúdo:
# - if
# - arquivos
# - diretórios
# - mkdir
# - cp
# - mv
# ============================================================

exercicio2() {

    clear

    echo "========================================"
    echo " EXERCÍCIO 2 - BACKUP DE ARQUIVOS"
    echo "========================================"
    echo ""

    read -p "Digite o nome do arquivo que deseja copiar: " arquivo


    # Validação
    if [ -z "$arquivo" ]; then

        echo ""
        echo "ERRO: O nome do arquivo não pode ficar vazio."

        pausar
        return
    fi


    # Verifica se o arquivo existe
    if [ -f "$arquivo" ]; then

        echo ""
        echo "Arquivo encontrado!"

        # Criação da pasta de trabalho
        mkdir -p trabalho

        # Criação da pasta de backup
        mkdir -p trabalho/backup

        # Copiando o arquivo
        cp "$arquivo" trabalho/backup/

        echo "Arquivo copiado para a pasta de backup."


        # Renomeando o arquivo
        mv "trabalho/backup/$arquivo" \
           "trabalho/backup/backup_$arquivo"

        echo "Arquivo renomeado para:"
        echo "backup_$arquivo"

        echo ""
        echo "Backup realizado com sucesso!"

    else

        echo ""
        echo "ERRO: O arquivo '$arquivo' não existe."

    fi

    pausar
}


# ============================================================
# EXERCÍCIO 3
# CALCULADORA COM CASE
#
# Conteúdo:
# - Entrada
# - Validação
# - case
# - Operações matemáticas
# ============================================================

exercicio3() {

    clear

    echo "========================================"
    echo " EXERCÍCIO 3 - CALCULADORA"
    echo "========================================"
    echo ""

    read -p "Digite o primeiro número: " n1
    read -p "Digite o segundo número: " n2


    # Validação
    if ! [[ "$n1" =~ ^-?[0-9]+$ ]] || \
       ! [[ "$n2" =~ ^-?[0-9]+$ ]]; then

        echo ""
        echo "ERRO: Digite apenas números inteiros."

        pausar
        return
    fi


    echo ""
    echo "Escolha uma operação:"
    echo ""
    echo "1 - Soma"
    echo "2 - Subtração"
    echo "3 - Multiplicação"
    echo "4 - Divisão"
    echo ""

    read -p "Opção: " operacao


    case "$operacao" in

        1)

            resultado=$((n1 + n2))

            echo ""
            echo "$n1 + $n2 = $resultado"
            ;;


        2)

            resultado=$((n1 - n2))

            echo ""
            echo "$n1 - $n2 = $resultado"
            ;;


        3)

            resultado=$((n1 * n2))

            echo ""
            echo "$n1 x $n2 = $resultado"
            ;;


        4)

            if [ "$n2" -eq 0 ]; then

                echo ""
                echo "ERRO: Não é possível dividir por zero."

            else

                resultado=$((n1 / n2))

                echo ""
                echo "$n1 / $n2 = $resultado"

            fi
            ;;


        *)

            echo ""
            echo "Opção inválida."
            ;;

    esac

    pausar
}


# ============================================================
# EXERCÍCIO 4
# TABUADA USANDO FOR
#
# Conteúdo:
# - Entrada
# - Validação
# - for
# ============================================================

exercicio4() {

    clear

    echo "========================================"
    echo " EXERCÍCIO 4 - TABUADA"
    echo "========================================"
    echo ""

    read -p "Digite um número para gerar a tabuada: " numero


    # Validação
    if ! [[ "$numero" =~ ^-?[0-9]+$ ]]; then

        echo ""
        echo "ERRO: Digite apenas números inteiros."

        pausar
        return
    fi


    echo ""
    echo "Tabuada do $numero"
    echo "--------------------"


    for i in {1..10}
    do

        resultado=$((numero * i))

        echo "$numero x $i = $resultado"

    done


    pausar
}


# ============================================================
# FUNCIONALIDADE EXTRA
# CONTAGEM COM WHILE
# ============================================================

contagem() {

    clear

    echo "========================================"
    echo " CONTAGEM COM WHILE"
    echo "========================================"
    echo ""

    read -p "Digite até qual número deseja contar: " limite


    if ! [[ "$limite" =~ ^[0-9]+$ ]]; then

        echo ""
        echo "ERRO: Digite um número inteiro positivo."

        pausar
        return
    fi


    contador=1

    echo ""

    while [ "$contador" -le "$limite" ]
    do

        echo "Número: $contador"

        contador=$((contador + 1))

    done

    pausar
}


# ============================================================
# FUNCIONALIDADE EXTRA
# INFORMAÇÕES DO SISTEMA
# ============================================================

informacoes() {

    clear

    echo "========================================"
    echo " INFORMAÇÕES DO SISTEMA"
    echo "========================================"
    echo ""

    echo "Usuário logado: $USER"

    echo "Diretório atual:"
    pwd

    echo ""
    echo "Data e hora:"
    date

    echo ""
    echo "Nome do script:"
    echo "$0"

    echo ""
    echo "PID do script:"
    echo "$$"

    echo ""
    echo "Sistema operacional:"
    uname -s

    echo ""
    echo "Nome da máquina:"
    hostname

    pausar
}


# ============================================================
# SCRIPT MESTRE
# MENU PRINCIPAL
#
# Conteúdo:
# - while
# - case
# - funções
# - múltiplas funcionalidades
# ============================================================

while true
do

    clear

    echo "=========================================="
    echo "       ATIVIDADE AVALIATIVA"
    echo "          SHELL SCRIPT"
    echo "=========================================="
    echo ""
    echo "1 - Exercício 1 - Validar número"
    echo "2 - Exercício 2 - Backup de arquivo"
    echo "3 - Exercício 3 - Calculadora"
    echo "4 - Exercício 4 - Tabuada"
    echo "5 - Contagem com WHILE"
    echo "6 - Informações do sistema"
    echo "0 - Sair"
    echo ""
    echo "=========================================="

    read -p "Escolha uma opção: " opcao


    case "$opcao" in

        1)
            exercicio1
            ;;

        2)
            exercicio2
            ;;

        3)
            exercicio3
            ;;

        4)
            exercicio4
            ;;

        5)
            contagem
            ;;

        6)
            informacoes
            ;;

        0)

            clear

            echo "=========================================="
            echo "       PROGRAMA FINALIZADO"
            echo "=========================================="
            echo ""

            echo "Até mais!"

            exit 0
            ;;

        *)

            echo ""
            echo "ERRO: Opção inválida."

            pausar
            ;;

    esac

done
