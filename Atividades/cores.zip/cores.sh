#!/bin/bash

# ==========================================================
# ATIVIDADE - CORES E FORMATAÇÃO NO BASH
# Objetivo:
# Utilizar códigos ANSI para exibir textos coloridos,
# aplicar estilos e reutilizar formatação por meio de função.
# ==========================================================

# Códigos ANSI
VERMELHO="\033[31m"
VERDE="\033[32m"
AMARELO="\033[33m"
AZUL="\033[34m"
NEGRITO="\033[1m"
SUBLINHADO="\033[4m"
RESET="\033[0m"


# ----------------------------------------------------------
# Função para exibir mensagens formatadas.
# Parâmetro 1: cor/estilo
# Parâmetro 2: mensagem
# ----------------------------------------------------------
mostrar_formatado() {
    echo -e "$1$2${RESET}"
}


# Título com negrito e cor azul
mostrar_formatado "${NEGRITO}${AZUL}" "=========================================="
mostrar_formatado "${NEGRITO}${AZUL}" "       PROGRAMA COLORIDO EM BASH"
mostrar_formatado "${NEGRITO}${AZUL}" "=========================================="

echo

# Mensagem sublinhada
mostrar_formatado "${SUBLINHADO}${AMARELO}" "Lista de opções disponíveis:"

echo

# Pequena lista com cores diferentes
mostrar_formatado "${VERDE}" "1 - Sistema funcionando corretamente"
mostrar_formatado "${AMARELO}" "2 - Atenção: verifique os dados"
mostrar_formatado "${VERMELHO}" "3 - Erro encontrado no sistema"
mostrar_formatado "${AZUL}" "4 - Informação do programa"

echo

# Mensagem final
mostrar_formatado "${NEGRITO}${VERDE}" "Programa finalizado com sucesso!"
