#!/bin/bash

echo "===================================="
echo "     VERIFICADOR DE NOTAS"
echo "===================================="

# Solicita uma nota ao usuário
read -p "Digite sua nota de 0 a 10: " nota

# Verifica as condições
if [ "$nota" -ge 7 ]; then
    echo "Resultado: APROVADO!"

elif [ "$nota" -ge 5 ]; then
    echo "Resultado: RECUPERAÇÃO!"

else
    echo "Resultado: REPROVADO!"
fi

echo "===================================="
echo "Verificação finalizada."
