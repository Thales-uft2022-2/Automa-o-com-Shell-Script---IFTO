#!/bin/bash

# ==========================================================
# ATIVIDADE 12 - FUNÇÕES EM SHELL SCRIPT
# Objetivo: praticar criação e utilização de funções.
# ==========================================================


# ----------------------------------------------------------
# Função 1: exibe o cabeçalho e o nome do programa.
# ----------------------------------------------------------
cabecalho() {
    clear
    echo "=========================================="
    echo "       SISTEMA DE FUNÇÕES - SHELL"
    echo "=========================================="
    echo
}


# ----------------------------------------------------------
# Função 2: recebe o nome do usuário e exibe uma saudação.
# ----------------------------------------------------------
saudar_usuario() {
    read -p "Digite seu nome: " nome

    # Validação para impedir nome vazio
    if [ -z "$nome" ]; then
        echo "Erro: o nome não pode ficar vazio."
        return 1
    fi

    echo
    echo "Olá, $nome! Seja bem-vindo ao programa."
    return 0
}


# ----------------------------------------------------------
# Função 3: calcula a soma de dois números.
# Esta função utiliza parâmetros ($1 e $2).
# ----------------------------------------------------------
somar_numeros() {
    numero1=$1
    numero2=$2

    resultado=$((numero1 + numero2))

    echo "$numero1 + $numero2 = $resultado"
}


# ----------------------------------------------------------
# Função 4: verifica se um número é par ou ímpar.
# ----------------------------------------------------------
verificar_par_impar() {
    numero=$1

    if [ $((numero % 2)) -eq 0 ]; then
        echo "O número $numero é PAR."
    else
        echo "O número $numero é ÍMPAR."
    fi
}


# ----------------------------------------------------------
# Função 5: valida se o valor informado é um número inteiro.
# Usa return:
# return 0 = número válido
# return 1 = número inválido
# ----------------------------------------------------------
validar_numero() {
    if [[ "$1" =~ ^-?[0-9]+$ ]]; then
        return 0
    else
        return 1
    fi
}


# ==========================================================
# PROGRAMA PRINCIPAL
# ==========================================================

cabecalho

saudar_usuario

# Verifica o retorno da função
if [ $? -ne 0 ]; then
    echo "Programa encerrado."
    exit 1
fi

echo
echo "========== SOMA DE DOIS NÚMEROS =========="
echo

read -p "Digite o primeiro número: " n1

if ! validar_numero "$n1"; then
    echo "Erro: digite um número inteiro válido."
    exit 1
fi

read -p "Digite o segundo número: " n2

if ! validar_numero "$n2"; then
    echo "Erro: digite um número inteiro válido."
    exit 1
fi

echo
somar_numeros "$n1" "$n2"


echo
echo "========== PAR OU ÍMPAR =========="
echo

read -p "Digite um número: " numero

if validar_numero "$numero"; then
    verificar_par_impar "$numero"
else
    echo "Erro: digite um número inteiro válido."
    exit 1
fi


echo
echo "=========================================="
echo "       PROGRAMA FINALIZADO"
echo "=========================================="
