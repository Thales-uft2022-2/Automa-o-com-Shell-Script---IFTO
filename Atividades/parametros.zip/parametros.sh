#!/bin/bash

# ==========================================================
# ATIVIDADE - PARÂMETROS PELA LINHA DE COMANDO
# Objetivo:
# Receber argumentos pela linha de comando, validar a
# quantidade de parâmetros e utilizar os valores recebidos.
# ==========================================================

echo "=========================================="
echo "       SCRIPT COM PARÂMETROS"
echo "=========================================="
echo

# Verifica se foram informados pelo menos 2 argumentos
if [ $# -lt 2 ]; then
    echo "ERRO: Você precisa informar pelo menos dois argumentos."
    echo
    echo "Modo de uso:"
    echo "./parametros.sh <nome> <idade>"
    echo
    echo "Exemplo:"
    echo "./parametros.sh Thales 25"
    exit 1
fi

# Armazena os argumentos recebidos
nome=$1
idade=$2

echo "Quantidade de argumentos recebidos: $#"
echo
echo "Primeiro argumento: $nome"
echo "Segundo argumento: $idade"

echo
echo "Olá, $nome!"
echo "Você informou que possui $idade anos."

echo
echo "=========================================="
echo "       SCRIPT FINALIZADO"
echo "=========================================="
