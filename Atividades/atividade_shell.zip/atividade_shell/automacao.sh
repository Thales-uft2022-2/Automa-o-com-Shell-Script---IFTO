#!/bin/bash

echo "===================================="
echo "   AUTOMAÇÃO DE ARQUIVOS - LINUX"
echo "===================================="

# Cria a pasta de trabalho
mkdir -p trabalho

# Cria a pasta de backup
mkdir -p backup

# Cria um arquivo de exemplo dentro da pasta de trabalho
echo "Arquivo criado para atividade de Shell Script." > trabalho/documento.txt

# Verifica se o arquivo existe
if [ -f "trabalho/documento.txt" ]; then

    echo "Arquivo encontrado!"

    # Copia o arquivo para a pasta de backup
    cp trabalho/documento.txt backup/

    echo "Arquivo copiado para a pasta de backup."

    # Renomeia o arquivo que foi copiado
    mv backup/documento.txt backup/documento_backup.txt

    echo "Arquivo renomeado para documento_backup.txt."

else

    echo "Erro: o arquivo documento.txt não existe."

fi

echo "===================================="
echo "Processo finalizado!"
echo "===================================="
